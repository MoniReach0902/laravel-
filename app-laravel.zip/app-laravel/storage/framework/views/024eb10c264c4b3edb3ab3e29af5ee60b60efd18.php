<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            All Category
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-lg-8 col-xl-8">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong><?php echo e(session('success')); ?></strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <div class="card-header">
                        All Category
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Category Name</th>
                                <th scope="col">User Name </th>
                                <th scope="col">Create At</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($categorys->firstItem()+$loop->index); ?></th>
                                <td><?php echo e($category->category_name); ?></td>
                                <td><?php echo e($category->user->name); ?></td>
                                <td>
                                    <?php if($category->created_at==NULL): ?>
                                    <span class="text-danger">No Date</span>
                                    <?php else: ?>
                                    <?php echo e(Carbon\Carbon::parse($category->created_at)->diffForHumans()); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(url('category/edit/'.$category->id)); ?>" class="btn btn-info">Edit</a>
                                    <a href="<?php echo e(url('softdelete/category/'.$category->id)); ?>" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($categorys->links()); ?>

                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <b>Add Category</b>
                            <div class="card-body">
                                <form action="<?php echo e(route('store.cantegory')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1" class="form-label">Category Name</label>
                                        <input type="text" name="category_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Save Category</button>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Trash -->
    <div class="py-12">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-lg-8 col-xl-8">
                    <div class="card-header">
                        Trash Category
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Category Name</th>
                                <th scope="col">User Name </th>
                                <th scope="col">Create At</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $trashCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($categorys->firstItem()+$loop->index); ?></th>
                                <td><?php echo e($category->category_name); ?></td>
                                <td><?php echo e($category->user->name); ?></td>
                                <td>
                                    <?php if($category->created_at==NULL): ?>
                                    <span class="text-danger">No Date</span>
                                    <?php else: ?>
                                    <?php echo e(Carbon\Carbon::parse($category->created_at)->diffForHumans()); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(url('category/resotre/'.$category->id)); ?>" class="btn btn-info">Resotre</a>
                                    <a href="<?php echo e(url('remove/category/'.$category->id)); ?>" class="btn btn-danger">Remove</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($trashCategory->links()); ?>

                </div>
                <div class="col-lg-4 col-md-4">

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\Laravel\app-laravel\resources\views/admin/category/index.blade.php ENDPATH**/ ?>