 
 <?php $__env->startSection('admin'); ?>


 <div class="card-body">
     <?php if(session('success')): ?>
     <div class="alert alert-success alert-dismissible fade show" role="alert">
         <strong><?php echo e(session('success')); ?></strong>
         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
     </div>
     <?php endif; ?>
     <h2>CREATE ABOUT</h2><BR></BR>
     <form action="<?php echo e(route('store.about')); ?>" method="POST" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
         <div class="form-group">
             <label for="exampleFormControlInput1">TITLE</label>
             <input type="text" name="title" class="form-control" id="exampleFormControlInput1" placeholder="Enter Title">
            
         </div>
         <div class="form-group">
             <label for="exampleFormControlInput1">SUB TITLE</label>
             <input type="text" name="sub_title" class="form-control" id="exampleFormControlInput1" placeholder="Enter Sub Title">
           
         </div>
         <div class="form-group">
             <label for="exampleFormControlTextarea1">DESCRIPTION</label>
             <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="3"></textarea>
         </div>
      
         <div class="form-footer pt-4 pt-5 mt-4 border-top">
             <button type="submit" class="btn btn-primary btn-default">Save</button>

         </div>
     </form>
 </div>


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Laravel\app-laravel\resources\views/admin/about/create.blade.php ENDPATH**/ ?>