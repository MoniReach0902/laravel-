 
 <?php $__env->startSection('admin'); ?>

 <div class="py-12">
     <div class="container">
         <div class="row">
             <div class="col-lg-8 col-md-8">
                 <div class="card">
                     <div class="card-header">
                         <b>Edit Brands</b>
                         <div class="card-body">
                             <form action="<?php echo e(url('brand/update/'.$brands->id)); ?>" method="POST" enctype="multipart/form-data">
                                 <?php echo csrf_field(); ?>
                                 <input type="hidden" name="old_img" value="<?php echo e($brands->brand_img); ?>">
                                 <div class="mb-3">
                                     <label for="exampleInputEmail1" class="form-label">Update Brand Name</label>
                                     <input type="text" name="brand_name" value="<?php echo e($brands->brand_name); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                     <?php $__errorArgs = ['brand_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <span class="text-danger"><?php echo e($message); ?></span>
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                 <div class="mb-3">
                                     <label for="exampleInputEmail1" class="form-label">Update Brand Photo</label>
                                     <input type="file" name="brand_img" value="<?php echo e($brands->brand_img); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">

                                     <?php $__errorArgs = ['brand_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                     <span class="text-danger"><?php echo e($message); ?></span>
                                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 </div>
                                 <div class="form-group">
                                     <img src="<?php echo e(asset($brands->brand_img)); ?>" alt="" style="width: 450px; height: 300px;">
                                 </div>
                                 <button type="submit" class="btn btn-primary">Update Brand</button>
                             </form>
                         </div>
                     </div>

                 </div>
             </div>
         </div>
     </div>
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Laravel\app-laravel\resources\views/admin/brand/edit.blade.php ENDPATH**/ ?>