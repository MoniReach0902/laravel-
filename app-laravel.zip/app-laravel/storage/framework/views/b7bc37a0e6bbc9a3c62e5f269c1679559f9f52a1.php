 
 <?php $__env->startSection('admin'); ?>

 <div class="py-12">
     <div class="container">
         <div class="row">
             <div style="margin-left: 15px; margin-bottom: 30px;">
                 <a href="<?php echo e(route('add.about')); ?>"><button class="btn btn-info">Add About</button></a><br>
             </div>
             <div class="col-md-12 col-lg-12 col-xl-12">
                 <?php if(session('success')): ?>
                 <div class="alert alert-success alert-dismissible fade show" role="alert">
                     <strong><?php echo e(session('success')); ?></strong>
                     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                 </div>
                 <?php endif; ?>
                 <div class="card-header">
                     Home About
                 </div>
                 <table class="table">
                     <thead>
                         <tr>
                             <th scope="col" width="5%">#</th>
                             <th scope="col" width="15%">Title</th>
                             <th scope="col" width="20%"> Sub Title </th>
                             <th scope="col" width="40%"> Description </th>
                             <th scope="col" width="20%">Action</th>
                         </tr>
                     </thead>
                     <tbody>
                         <?php ($i=1); ?>
                         <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                             <th scope="row"><?php echo e($i++); ?></th>
                             <td><?php echo e($about->title); ?></td>
                             <td><?php echo e($about->sub_title); ?></td>
                             <td><?php echo e($about->description); ?></td>
                             <td>
                                 <a href="<?php echo e(url('about/edit/'.$about->id)); ?>" class="btn btn-info">Edit</a>
                                 <a href="<?php echo e(url('about/delete/'.$about->id)); ?>" onclick="return confirm('Are You Sure To Delete?')" class="btn btn-danger">Delete</a>
                             </td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                 </table>
             </div>
         </div>
     </div>
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Laravel\app-laravel\resources\views/admin/about/index.blade.php ENDPATH**/ ?>