<?php

namespace App\Http\Controllers;

use App\Models\Slider;
use Illuminate\Http\Request;
use Image;
use Carbon\Carbon;
class HomeController extends Controller
{
    //
   
    public function homeSlider(){
        $sliders=Slider::latest()->get();
        return view('admin.slider.index',compact('sliders'));
    }
    public function addSlider(){
        return view('admin.slider.create');
    }
    public function storeSlider(Request $request){
        $image = $request->file('image');
        $name_gen = hexdec(uniqid()) . '.' . $image->getClientOriginalExtension();
        Image::make($image)->resize(1920, 1088)->save('img/slide/' . $name_gen);
        $last_img = 'img/slide/' . $name_gen;

        Slider::insert([
            'title' => $request->input('title'),
            'description' => $request->input('description'),
            'image' => $last_img,
            'created_at' => Carbon::now(),
        ]);
        return redirect()->back()->with('success', 'Slide insert successfully');
    }
}
