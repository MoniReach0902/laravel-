<?php

namespace App\Http\Controllers;

use App\Models\HomeAbout;
use App\Models\Multipic;
use Carbon\Carbon;
use Illuminate\Http\Request;

class HomeAboutController extends Controller
{
    //
   
    public function homeIndex(){
        $abouts=HomeAbout::all();
        return view('admin.about.index',compact('abouts'));
    }
    public function addAbout(){
        return view('admin.about.create');
    }
     public function storeAbout(Request $request)
    {
        HomeAbout::insert([
            'title'=>$request->input('title'),
            'sub_title'=>$request->input('sub_title'),
            'description'=>$request->description,
            'created_at'=>Carbon::now(),
        ]);
        return redirect('home/about')->with('success','insert successfully');
    }
    public function editAbout($id){
        $homeAbout=HomeAbout::find($id);
        return view('admin.about.edit',compact('homeAbout'));
    }
    public function updateAbout(Request $request,$id){
        $homeAbout=HomeAbout::find($id)->update([
            'title' => $request->input('title'),
            'sub_title' => $request->input('sub_title'),
            'description' => $request->description,
            
        ]);
        return redirect()->back()->with('success', 'update successfully');
    }
    public function deleteAbout($id){
        $delete=HomeAbout::find($id)->delete();
        return redirect()->back()->with('success', 'delete successfully');
    }
    public function portfolio(){
        $images=Multipic::all();
        return view('page.portfolio',compact('images'));
    }
}
