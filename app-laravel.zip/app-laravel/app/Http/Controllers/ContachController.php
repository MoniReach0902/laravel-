<?php

namespace App\Http\Controllers;

use App\Models\Contach;
use App\Models\ContachForm;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ContachController extends Controller

{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $contaches=DB::table('contaches')->first();
        return view('page.contach',compact('contaches'));
    }
    public function contach(){
        $contaches=Contach::all();
        return view('admin.contach.index',compact('contaches'));
    }
    public function addContach(){
        return view('admin.contach.create');
    }
    public function storeContach(Request $request){

        $contach=Contach::insert([
            'address'=>$request->input('address'),
            'email'=>$request->input('email'),
            'phone'=>$request->input('phone'),
            'created_at'=>Carbon::now(),
        ]);
        return redirect()->back()->with('success','insert successfully');
    }
    public function contachForm(Request $request){

        ContachForm::insert([
            'name'=>$request->input('name'),
            'email'=>$request->input('email'),
            'subjech'=>$request->input('subject'),
            'message'=>$request->input('message'),
            'created_at'=>Carbon::now(),
            
        ]);
        return redirect()->back()->with('success', 'Message is Send successfully');
    }
    public function contachMessage(){
        $message=ContachForm::all();
        return view('admin.contach.message',compact('message'));
    }
}
