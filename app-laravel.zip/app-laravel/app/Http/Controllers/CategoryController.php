<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\ViewErrorBag;

class CategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    //
    public function allCategory(){
        $categorys=Category::latest()->paginate(4);
        $trashCategory=Category::onlyTrashed()->latest()->paginate(3);
        return view('admin.category.index',compact('categorys', 'trashCategory'));
    }
    public function addCategory(Request $request){
        $validate=$request->validate(
            ['category_name' => 'required|unique:categories|max:255',],
            [
                'category_name.required' => 'Please input category name',
                'category_name.max' => 'Category less than 250',
            
            ]
        );
        Category::insert([
            'category_name'=>$request->input('category_name'),
            'user_id'=>Auth::user()->id,
            'created_at'=>Carbon::now(),
        ]);
        // $category=new Category;
        // $category->category_name=$request->category_name;
        // $category->user_id=Auth::user()->id;
        // $category->save();

        // query builder
            // $data=array();
            // $data['category_name']=$request->category_name;
            // $data['user_id']=Auth::user()->id;
            // DB::table('categories')->insert($data);

        return redirect()->back()->with('success','Category add successfully');
        
    }
    public function editCategory($id){
        $category=Category::find($id);
        return view('admin.category.edit',compact('category'));
    }
    public function updateCategory(Request $request,$id){
        $update=Category::find($id)->update([
            'category_name'=>$request->category_name,
            'user_id'=>Auth::user()->id,
        ]);
        return redirect()->route('all.category')->with('success', 'Category Updated successfully');
    }
    public function deleteCategory($id){
        $delete=Category::find($id)->delete();
        return redirect()->back()->with('success','Category Deleted Sucessfully');
    }
    public function resotreCategory($id){
        $delete=Category::withTrashed()->find($id)->restore();
        return redirect()->back()->with('success', 'Category Resotre Sucessfully');
    }
    public function removeCategory($id){
        $delete=Category::onlyTrashed()->find($id)->forceDelete();
        return redirect()->back()->with('success', 'Category Removed Sucessfully');
    }
}
