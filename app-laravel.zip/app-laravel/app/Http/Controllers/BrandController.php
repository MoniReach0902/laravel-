<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Multipic;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Image;


class BrandController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    //
    public function allBrand(){
        $brands=Brand::latest()->paginate(5);
        return view('admin.brand.index',compact('brands'));
    }
    public function storeBrand(Request $request){
        $validate = $request->validate(
            [
                'brand_name' => 'required|unique:brands|min:4',
                'brand_img' => 'required|mimes:jpeg,png,jiff',
            ],
            [
                'brand_name.required' => 'Please input brand name',
                'brand_name.min' => 'Brand name more than 4 characters',

            ]
        );
        // $brand_img=$request->file('brand_img');
        // $name_gen=hexdec(uniqid());
        // $img_ext=strtolower($brand_img->getClientOriginalExtension());
        // $img_name=$name_gen.'.'.$img_ext;
        // $toLocation='img/brand/';
        // $last_img=$toLocation.$img_name;
        // $brand_img->move($toLocation,$img_name);
        $brand_img = $request->file('brand_img');
        $name_gen = hexdec(uniqid()).'.'. $brand_img->getClientOriginalExtension();
        Image::make($brand_img)->resize(300,200)->save('img/brand/'.$name_gen);
        $last_img= 'img/brand/'.$name_gen;

        Brand::insert([
            'brand_name'=>$request->input('brand_name'),
            'brand_img'=>$last_img,
            'created_at'=>Carbon::now(),
        ]);
        $notification=array(
            'message'=>'success','Brand insert successfully',
            'alert-type'=>'success'
        );
        return redirect()->back()->with($notification);
    }
    public function edit($id){
        $brands=Brand::find($id);
        return view('admin.brand.edit',compact('brands'));

    }
    public function update(Request $request,$id){
        $validate = $request->validate(
            [
                'brand_name' => 'required|min:4',
            ],
            [
                'brand_name.required' => 'Please input brand name',
                'brand_name.min' => 'Brand name more than 4 characters',

            ]
        );
       
        $old_img=$request->old_img;
        $brand_img = $request->file('brand_img');
        if($brand_img){
            $name_gen = hexdec(uniqid());
            $img_ext = strtolower($brand_img->getClientOriginalExtension());
            $img_name = $name_gen . '.' . $img_ext;
            $toLocation = 'img/brand/';
            $last_img = $toLocation . $img_name;
            $brand_img->move($toLocation, $img_name);
            unlink($old_img);
            Brand::find($id)->update([
                'brand_name' => $request->input('brand_name'),
                'brand_img' => $last_img,
                'created_at' => Carbon::now(),
            ]);
            $notification = array(
                'message' =>  'Brand update successfully',
                'alert-type' => 'info'
            );
            return redirect()->back()->with($notification);
        }else{
            Brand::find($id)->update([
                'brand_name' => $request->input('brand_name'),
             
                'created_at' => Carbon::now(),
            ]);
            $notification = array(
                'message' => 'Brand update successfully',
                'alert-type' => 'warning'
            );
            return redirect()->back()->with($notification);
        }
    }
    public function distroy($id){
        $image=Brand::find($id);
        $old_img=$image->brand_img;
        unlink($old_img);
        Brand::find($id)->delete();
        $notification = array(
            'message' => 'Brand delete successfully',
            'alert-type' => 'error'
        );
        return redirect()->back()->with($notification);
    }
    // multiImage
    public function multiImage(){
        $images=Multipic::all();
        return view('admin.multipic.index',compact('images'));
    }
    public function storeImage(Request $request){
        $multi_img = $request->file('image');

        foreach ($multi_img as $img) {
            $name_gen = hexdec(uniqid()) . '.' . $img->getClientOriginalExtension();
            Image::make($img)->resize(300, 300)->save('img/multi/' . $name_gen);
            $last_img = 'img/multi/' . $name_gen;
            Multipic::insert([
                'image' => $last_img,
                'created_at' => Carbon::now(),
            ]);
        }
        return redirect()->back()->with('success', 'Brand insert successfully');
    }
    public function logout(){
        Auth::logout();
        return redirect()->route('login')->with('success','User Logout');
    }
}
