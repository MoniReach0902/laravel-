<?php

use App\Http\Controllers\BrandController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ChangePasswords;
use App\Http\Controllers\ContachController;
use App\Http\Controllers\HomeAboutController;
use App\Http\Controllers\HomeController;
use App\Models\HomeAbout;
use App\Models\Multipic;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    $brands=DB::table('brands')->get();
    $abouts=HomeAbout::first();
    $images=Multipic::all();
    return view('home',compact('brands', 'abouts','images'));
});
// Category controller
Route::get('/category/all',[CategoryController::class,'allCategory'])->name('all.category');
Route::post('/category/add', [CategoryController::class, 'addCategory'])->name('store.cantegory');
Route::get('/category/edit/{id}', [CategoryController::class, 'editCategory']);
Route::post('/category/update/{id}', [CategoryController::class, 'updateCategory']);
Route::get('/softdelete/category/{id}', [CategoryController::class, 'deleteCategory']);
Route::get('/category/resotre/{id}', [CategoryController::class, 'resotreCategory']);
Route::get('/remove/category/{id}', [CategoryController::class, 'removeCategory']);

// Brand route
Route::get('/brand/all', [BrandController::class, 'allBrand'])->name('all.brand');
Route::post('/brand/add', [BrandController::class, 'storeBrand'])->name('store.brand');
Route::get('/brand/edit/{id}', [BrandController::class, 'edit']);
Route::post('/brand/update/{id}', [BrandController::class, 'update']);
Route::get('/brand/delete/{id}', [BrandController::class, 'distroy']);

// Multi Image
Route::get('/multi/image', [BrandController::class, 'multiImage'])->name('multi.image');
Route::post('/multiImage/add', [BrandController::class, 'storeImage'])->name('store.image');

Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', function () {
    // $users=User::all();
    $users=DB::table('users')->get();
    return view('admin.index');
})->name('dashboard');
Route::get('/user/imalogout', [BrandController::class, 'logout'])->name('user.logout');

//admin all route
Route::get('/home/slider', [HomeController::class, 'homeSlider'])->name('home.slider');
Route::get('/add/slider', [HomeController::class, 'addSlider'])->name('add.slider');
Route::post('/store/slider', [HomeController::class, 'storeSlider'])->name('store.slider');

// home about
Route::get('/home/about', [HomeAboutController::class, 'homeIndex'])->name('home.about');
Route::get('/add/about', [HomeAboutController::class, 'addAbout'])->name('add.about');
Route::post('/store/about', [HomeAboutController::class, 'storeAbout'])->name('store.about');
Route::get('/about/edit/{id}', [HomeAboutController::class, 'editAbout']);
Route::post('/about/update/{id}', [HomeAboutController::class, 'updateAbout']);
Route::get('about/delete/{id}',[HomeAboutController::class,'deleteAbout']);

// Portfolio
Route::get('/porfolio', [HomeAboutController::class, 'portfolio'])->name('portfolio');

// contach page
Route::get('/contaches', [ContachController::class, 'contach'])->name('contaches');
Route::get('/add/contach', [ContachController::class, 'addContach'])->name('add.contach');
Route::post('/store/contach', [ContachController::class, 'storeContach'])->name('store.contach');

// Home contach page 
Route::get('/contach',[ContachController::class,'index']);
Route::post('/contach/form', [ContachController::class, 'contachForm'])->name('contach.form');
Route::get('/contach/message', [ContachController::class, 'contachMessage'])->name('contach.message');


// Change passwords route
Route::get('/user/passwords', [ChangePasswords::class, 'changePasswords'])->name('change.passwords');
Route::post('/passwords/update', [ChangePasswords::class, 'updatePasswords'])->name('passwords.update');

// user profile
Route::get('/user/profile', [ChangePasswords::class, 'profileUpdate'])->name('profile.update');
Route::post('/profile/update', [ChangePasswords::class, 'userUpdate'])->name('user_profile.update');