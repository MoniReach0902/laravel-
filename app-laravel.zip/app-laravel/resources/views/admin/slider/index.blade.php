 @extends('admin.admin_master')
 @section('admin')

 <div class="py-12">
     <div class="container">
         <div class="row">

             <div style="margin-left: 15px; margin-bottom: 30px;">
                 <a href="{{route('add.slider')}}"><button class="btn btn-info">Add Slider</button></a><br>
             </div>
             <div class="col-md-12 col-lg-12 col-xl-12">
                 @if(session('success'))
                 <div class="alert alert-success alert-dismissible fade show" role="alert">
                     <strong>{{session('success')}}</strong>
                     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                 </div>
                 @endif
                 <div class="card-header">
                     All Slider
                 </div>
                 <table class="table">
                     <thead>
                         <tr>
                             <th scope="col" width="5%">#</th>
                             <th scope="col" width="15%">Title</th>
                             <th scope="col" width="35%"> Description </th>
                             <th scope="col" width="20%"> Photo </th>

                             <th scope="col" width="25%">Action</th>
                         </tr>
                     </thead>
                     <tbody>
                         @php($i=1)
                         @foreach($sliders as $slide)
                         <tr>
                             <th scope="row">{{$i++}}</th>
                             <td>{{$slide->title}}</td>
                             <td>{{$slide->description}}</td>
                             <td><img src="{{asset($slide->image)}}" alt="{{$slide->image}}" style="width: 70px;height: 50px;"></td>

                             <td>
                                 <a href="{{url('slide/edit/'.$slide->id)}}" class="btn btn-info">Edit</a>
                                 <a href="{{url('slide/delete/'.$slide->id)}}" onclick="return confirm('Are You Sure To Delete?')" class="btn btn-danger">Delete</a>
                             </td>
                         </tr>
                         @endforeach
                     </tbody>
                 </table>
             </div>
         </div>
     </div>
 </div>
 @endsection