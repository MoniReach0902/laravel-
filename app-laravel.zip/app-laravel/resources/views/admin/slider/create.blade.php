 @extends('admin.admin_master')
 @section('admin')


 <div class="card-body">
     @if(session('success'))
     <div class="alert alert-success alert-dismissible fade show" role="alert">
         <strong>{{session('success')}}</strong>
         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
     </div>
     @endif
     <h2>CREATE SLIDER</h2><BR></BR>
     <form action="{{route('store.slider')}}" method="POST" enctype="multipart/form-data">
         @csrf
         <div class="form-group">
             <label for="exampleFormControlInput1">Title</label>
             <input type="text" name="title" class="form-control" id="exampleFormControlInput1" placeholder="Enter Title">
             <span class="mt-2 d-block">We'll never share your email with anyone else.</span>
         </div>



         <div class="form-group">
             <label for="exampleFormControlTextarea1">Description</label>
             <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="3"></textarea>
         </div>
         <div class="form-group">
             <label for="exampleFormControlFile1">Photo</label>
             <input type="file" name="image" class="form-control-file" id="exampleFormControlFile1">
         </div>
         <div class="form-footer pt-4 pt-5 mt-4 border-top">
             <button type="submit" class="btn btn-primary btn-default">Save</button>

         </div>
     </form>
 </div>


 @endsection