 @extends('admin.admin_master')
 @section('admin')


 <div class="card-body">
     @if(session('success'))
     <div class="alert alert-success alert-dismissible fade show" role="alert">
         <strong>{{session('success')}}</strong>
         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
     </div>
     @endif
     <h2>EDIT ABOUT</h2><BR></BR>
     <form action="{{url('about/update/'.$homeAbout->id)}}" method="POST" enctype="multipart/form-data">
         @csrf
         <div class="form-group">
             <label for="exampleFormControlInput1">TITLE</label>
             <input type="text" name="title" class="form-control" id="exampleFormControlInput1" value="{{$homeAbout->title}}">

         </div>
         <div class="form-group">
             <label for="exampleFormControlInput1">SUB TITLE</label>
             <input type="text" name="sub_title" class="form-control" id="exampleFormControlInput1" placeholder="Enter Sub Title" value="{{$homeAbout->sub_title}}">

         </div>
         <div class="form-group">
             <label for="exampleFormControlTextarea1">DESCRIPTION</label>
             <textarea class="form-control" name="description" id="exampleFormControlTextarea1" rows="5" >{{$homeAbout->description}}</textarea>
         </div>

         <div class="form-footer pt-4 pt-5 mt-4 border-top">
             <button type="submit" class="btn btn-primary btn-default">Update</button>

         </div>
     </form>
 </div>


 @endsection