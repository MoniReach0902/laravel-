<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            All Category
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-lg-8 col-xl-8">
                    @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>{{session('success')}}</strong>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    @endif
                    <div class="card-header">
                        All Category
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Category Name</th>
                                <th scope="col">User Name </th>
                                <th scope="col">Create At</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($categorys as $category)
                            <tr>
                                <th scope="row">{{$categorys->firstItem()+$loop->index}}</th>
                                <td>{{$category->category_name}}</td>
                                <td>{{$category->user->name}}</td>
                                <td>
                                    @if($category->created_at==NULL)
                                    <span class="text-danger">No Date</span>
                                    @else
                                    {{Carbon\Carbon::parse($category->created_at)->diffForHumans()}}
                                    @endif
                                </td>
                                <td>
                                    <a href="{{url('category/edit/'.$category->id)}}" class="btn btn-info">Edit</a>
                                    <a href="{{url('softdelete/category/'.$category->id)}}" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    {{$categorys->links()}}
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <b>Add Category</b>
                            <div class="card-body">
                                <form action="{{route('store.cantegory')}}" method="POST">
                                    @csrf
                                    <div class="mb-3">
                                        <label for="exampleInputEmail1" class="form-label">Category Name</label>
                                        <input type="text" name="category_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        @error('category_name')
                                        <span class="text-danger">{{$message}}</span>
                                        @enderror
                                    </div>
                                    <button type="submit" class="btn btn-primary">Save Category</button>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Trash -->
    <div class="py-12">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-lg-8 col-xl-8">
                    <div class="card-header">
                        Trash Category
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Category Name</th>
                                <th scope="col">User Name </th>
                                <th scope="col">Create At</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($trashCategory as $category)
                            <tr>
                                <th scope="row">{{$categorys->firstItem()+$loop->index}}</th>
                                <td>{{$category->category_name}}</td>
                                <td>{{$category->user->name}}</td>
                                <td>
                                    @if($category->created_at==NULL)
                                    <span class="text-danger">No Date</span>
                                    @else
                                    {{Carbon\Carbon::parse($category->created_at)->diffForHumans()}}
                                    @endif
                                </td>
                                <td>
                                    <a href="{{url('category/resotre/'.$category->id)}}" class="btn btn-info">Resotre</a>
                                    <a href="{{url('remove/category/'.$category->id)}}" class="btn btn-danger">Remove</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    {{$trashCategory->links()}}
                </div>
                <div class="col-lg-4 col-md-4">

                </div>
            </div>
        </div>
    </div>
</x-app-layout>