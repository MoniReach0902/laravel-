 @extends('admin.admin_master')
 @section('admin')

 <div class="card card-default">
     <div class="card-header card-header-border-bottom">
         <h2>User Profile Update</h2>
     </div>
     @if(session('success'))
     <div class="alert alert-success alert-dismissible fade show" role="alert">
         <strong>{{session('success')}}</strong>
         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
     </div>
     @endif
     <div class="card-body">
         <form class="form-pill" method="POST" action="{{route('user_profile.update')}}">
             @csrf
             <div class="form-group">
                 <label for="exampleFormControlInput3">Name</label>
                 <input type="text" name="name" class="form-control" id="" value="{{$user['name']}}">
                 @error('name')
                 <span class="text-danger">{{$message}}</span>
                 @enderror
             </div>
             <div class="form-group">
                 <label for="exampleFormControlInput3">Email</label>
                 <input type="text" name="email" class="form-control" id="" value="{{$user['email']}}">
                 @error('email')
                 <span class="text-danger">{{$message}}</span>
                 @enderror
             </div>
             <button class="btn btn-primary btn-default" type="submit">Update</button>

         </form>
     </div>
 </div>
 @endsection