 @extends('admin.admin_master')
 @section('admin')

 <div class="card card-default">
     <div class="card-header card-header-border-bottom">
         <h2>Change Passwords</h2>
     </div>
     <div class="card-body">
         <form class="form-pill" method="POST" action="{{route('passwords.update')}}">
             @csrf
             <div class="form-group">
                 <label for="exampleFormControlInput3">Current Passwords</label>
                 <input type="password" name="old_passwords" class="form-control" id="current_password" placeholder="Current Passwords">
                 @error('old_passwords')
                 <span class="text-danger">{{$message}}</span>
                 @enderror
             </div>
             <div class="form-group">
                 <label for="exampleFormControlPassword3">New Password</label>
                 <input type="password" name="password" class="form-control" id="password" placeholder="New Password">
                 @error('password')
                 <span class="text-danger">{{$message}}</span>
                 @enderror
             </div>
             <div class="form-group">
                 <label for="exampleFormControlPassword3">Confirm Password</label>
                 <input type="password" name="password_confirmation" class="form-control" id="password_confirmation" placeholder="Confirm Password">
                 @error('confirm_passwords')
                 <span class="text-danger">{{$message}}</span>
                 @enderror
             </div>
             <button class="btn btn-primary btn-default" type="submit">Save</button>

         </form>
     </div>
 </div>
 @endsection