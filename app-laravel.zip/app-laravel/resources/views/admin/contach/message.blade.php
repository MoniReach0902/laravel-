 @extends('admin.admin_master')
 @section('admin')

 <div class="py-12">
     <div class="container">
         <div class="row">
          
             <div class="col-md-12 col-lg-12 col-xl-12">
                 @if(session('success'))
                 <div class="alert alert-success alert-dismissible fade show" role="alert">
                     <strong>{{session('success')}}</strong>
                     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                 </div>
                 @endif
                 <div class="card-header">
                     Contach Messages
                 </div>
                 <table class="table">
                     <thead>
                         <tr>
                             <th scope="col" width="5%">#</th>
                             <th scope="col" width="15%">Name</th>
                             <th scope="col" width="20%"> Email </th>
                             <th scope="col" width="40%"> Subject </th>
                             <th scope="col" width="20%">Messages</th>
                             <th scope="col" width="20%">Action</th>
                         </tr>
                     </thead>
                     <tbody>
                         @php($i=1)
                         @foreach($message as $msg)
                         <tr>
                             <th scope="row">{{$i++}}</th>
                             <td>{{$msg->name}}</td>
                             <td>{{$msg->email}}</td>
                             <td>{{$msg->subjech}}</td>
                             <td>{{$msg->message}}</td>
                             <td>

                                 <a href="{{url('message/delete/'.$msg->id)}}" onclick="return confirm('Are You Sure To Delete?')" class="btn btn-danger">Delete</a>
                             </td>
                         </tr>
                         @endforeach
                     </tbody>
                 </table>
             </div>
         </div>
     </div>
 </div>
 @endsection