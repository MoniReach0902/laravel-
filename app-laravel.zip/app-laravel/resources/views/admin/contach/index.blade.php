 @extends('admin.admin_master')
 @section('admin')

 <div class="py-12">
     <div class="container">
         <div class="row">
             <div style="margin-left: 15px; margin-bottom: 30px;">
                 <a href="{{route('add.contach')}}"><button class="btn btn-info">Add contach</button></a><br>
             </div>
             <div class="col-md-12 col-lg-12 col-xl-12">
                 @if(session('success'))
                 <div class="alert alert-success alert-dismissible fade show" role="alert">
                     <strong>{{session('success')}}</strong>
                     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                 </div>
                 @endif
                 <div class="card-header">
                     Contach Page
                 </div>
                 <table class="table">
                     <thead>
                         <tr>
                             <th scope="col" width="5%">#</th>
                             <th scope="col" width="15%">Address</th>
                             <th scope="col" width="20%"> Email </th>
                             <th scope="col" width="40%"> Phone </th>
                             <th scope="col" width="20%">Action</th>
                         </tr>
                     </thead>
                     <tbody>
                         @php($i=1)
                         @foreach($contaches as $contach)
                         <tr>
                             <th scope="row">{{$i++}}</th>
                             <td>{{$contach->address}}</td>
                             <td>{{$contach->email}}</td>
                             <td>{{$contach->phone}}</td>
                             <td>
                                 <a href="{{url('contach/edit/'.$contach->id)}}" class="btn btn-info">Edit</a>
                                 <a href="{{url('contach/delete/'.$contach->id)}}" onclick="return confirm('Are You Sure To Delete?')" class="btn btn-danger">Delete</a>
                             </td>
                         </tr>
                         @endforeach
                     </tbody>
                 </table>
             </div>
         </div>
     </div>
 </div>
 @endsection