 @extends('admin.admin_master')
 @section('admin')


 <div class="card-body">
     @if(session('success'))
     <div class="alert alert-success alert-dismissible fade show" role="alert">
         <strong>{{session('success')}}</strong>
         <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
     </div>
     @endif
     <h2>CREATE CONTACH</h2><BR></BR>
     <form action="{{route('store.contach')}}" method="POST" enctype="multipart/form-data">
         @csrf
         <div class="form-group">
             <label for="exampleFormControlInput1">Email</label>
             <input type="text" name="email" class="form-control" id="exampleFormControlInput1" placeholder="Enter contach email">

         </div>
         <div class="form-group">
             <label for="exampleFormControlInput1">Phone</label>
             <input type="text" name="phone" class="form-control" id="exampleFormControlInput1" placeholder="Enter phone">

         </div>
         <div class="form-group">
             <label for="exampleFormControlTextarea1">Address</label>
             <textarea class="form-control" name="address" id="exampleFormControlTextarea1" rows="3"></textarea>
         </div>

         <div class="form-footer pt-4 pt-5 mt-4 border-top">
             <button type="submit" class="btn btn-primary btn-default">Save</button>

         </div>
     </form>
 </div>


 @endsection