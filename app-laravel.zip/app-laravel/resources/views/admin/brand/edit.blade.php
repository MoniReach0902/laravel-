 @extends('admin.admin_master')
 @section('admin')

 <div class="py-12">
     <div class="container">
         <div class="row">
             <div class="col-lg-8 col-md-8">
                 <div class="card">
                     <div class="card-header">
                         <b>Edit Brands</b>
                         <div class="card-body">
                             <form action="{{url('brand/update/'.$brands->id)}}" method="POST" enctype="multipart/form-data">
                                 @csrf
                                 <input type="hidden" name="old_img" value="{{$brands->brand_img}}">
                                 <div class="mb-3">
                                     <label for="exampleInputEmail1" class="form-label">Update Brand Name</label>
                                     <input type="text" name="brand_name" value="{{$brands->brand_name}}" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                     @error('brand_name')
                                     <span class="text-danger">{{$message}}</span>
                                     @enderror
                                 </div>
                                 <div class="mb-3">
                                     <label for="exampleInputEmail1" class="form-label">Update Brand Photo</label>
                                     <input type="file" name="brand_img" value="{{$brands->brand_img}}" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">

                                     @error('brand_img')
                                     <span class="text-danger">{{$message}}</span>
                                     @enderror
                                 </div>
                                 <div class="form-group">
                                     <img src="{{asset($brands->brand_img)}}" alt="" style="width: 450px; height: 300px;">
                                 </div>
                                 <button type="submit" class="btn btn-primary">Update Brand</button>
                             </form>
                         </div>
                     </div>

                 </div>
             </div>
         </div>
     </div>
 </div>
 @endsection